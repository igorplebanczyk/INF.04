﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _2023_01_01_d
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
