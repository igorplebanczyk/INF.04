﻿int[] array = new int[10];
Console.WriteLine("Podaj 10 liczb całkowitych w kolejnych liniach:");
for (int i = 0; i < 10; i++) array[i] = int.Parse(Console.ReadLine());

SelectionSort selectionSort = new(array);
selectionSort.Sort();

Console.WriteLine();
Console.Write("Elementy tablicy po posortowaniu: ");
foreach (int elem in selectionSort.array) Console.Write(elem + " ");


class SelectionSort
{
    public int[] array;

    public SelectionSort(int[] array)
    {
        this.array = array;
    }

    /********************************************************
    * nazwa funkcji: Sort
    * parametry wejściowe: brak
    * wartość zwracana: brak
    * autor: 01234567890
    * ****************************************************/
    public void Sort()
    {
        for (int i = 0; i < array.Length; i++)
        {
            int maxIndex = FindMaxValueIndex(i, array.Length);

            (array[maxIndex], array[i]) = (array[i], array[maxIndex]);
        }
    }

    /********************************************************
    * nazwa funkcji: FindMaxValueIndex
    * parametry wejściowe: start - indeks od którego należy zacząć poszukiwania,
                           end - indeks do którego należy szukać
    * wartość zwracana: int - indeks maksymalnej wartości w tablicy
    * autor: 01234567890
    * ****************************************************/
    private int FindMaxValueIndex(int start, int end) {
        int max = int.MinValue;
        int maxIndex = -1;

        for (int i = start; i < end; i++)
        {
            if (array[i] > max)
            {
                max = array[i];
                maxIndex = i;
            }
        }

        return maxIndex;
    }
}