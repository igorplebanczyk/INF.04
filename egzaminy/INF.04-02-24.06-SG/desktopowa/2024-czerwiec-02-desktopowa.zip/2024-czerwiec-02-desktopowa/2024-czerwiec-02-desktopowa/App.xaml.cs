﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _2024_czerwiec_02_desktopowa
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
