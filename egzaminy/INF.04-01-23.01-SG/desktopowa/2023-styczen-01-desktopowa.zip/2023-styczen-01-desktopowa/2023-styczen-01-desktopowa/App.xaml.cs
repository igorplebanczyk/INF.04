﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _2023_styczen_01_desktopowa
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
